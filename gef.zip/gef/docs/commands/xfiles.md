## Command `xfiles`

`xfiles` is a more convenient representation of the GDB native command, `info files` allowing you to
filter by pattern given in argument. For example, if you only want to show the code sections (i.e.
`.text`):

![xfiles-example](https://i.imgur.com/lelnJ5B.png)
