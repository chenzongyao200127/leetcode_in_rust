## Command `gef help`

Displays the help menu for the loaded GEF commands.

```text
gef➤ gef help
```
