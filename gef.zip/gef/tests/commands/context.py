"""
`context` command test module
"""


from tests.base import RemoteGefUnitTestGeneric


class ContextCommand(RemoteGefUnitTestGeneric):
    """`context` command test module"""


    cmd = "context"


    # See https://github.com/hugsy/gef/projects/10
